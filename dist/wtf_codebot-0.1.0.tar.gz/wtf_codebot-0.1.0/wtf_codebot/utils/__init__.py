"""Utility functions for WTF CodeBot."""
