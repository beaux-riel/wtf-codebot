"""Core functionality for WTF CodeBot."""
