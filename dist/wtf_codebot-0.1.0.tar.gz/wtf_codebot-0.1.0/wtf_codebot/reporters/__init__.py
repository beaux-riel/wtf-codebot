"""Output reporters for WTF CodeBot."""
